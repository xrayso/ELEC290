package com.example.arcway_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
