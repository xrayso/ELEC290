import 'dart:async';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:google_ml_kit/google_ml_kit.dart';

class FaceScanPage extends StatefulWidget {
  const FaceScanPage({super.key});

  @override
  _FaceScanPageState createState() => _FaceScanPageState();
}

class _FaceScanPageState extends State<FaceScanPage> {
  late CameraController _cameraController;
  late List<CameraDescription> _cameras;
  late CameraDescription _firstCamera;
  late FaceDetector _faceDetector;
  bool _isDetecting = false;
  String _instruction = "Look straight for 3 seconds";

  @override
  void initState() {
    super.initState();
    _initializeCamera();
    _faceDetector = GoogleMlKit.vision.faceDetector();
  }

  // Initialize camera
  Future<void> _initializeCamera() async {
    try {
      _cameras = await availableCameras();
      _firstCamera = _cameras.first;
      _cameraController = CameraController(
        _firstCamera,
        ResolutionPreset.high,
      );

      await _cameraController.initialize();
      if (!mounted) return;
      setState(() {}); // Camera feed ready
      _startFaceScan();
    } catch (e) {
      _showError("Error initializing camera: $e");
    }
  }

  // Show error message
  void _showError(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK"),
          ),
        ],
      ),
    );
  }

  // Start scanning face
  Future<void> _startFaceScan() async {
    try {
      Timer(const Duration(seconds: 3), () {
        setState(() {
          _instruction = "Look left for 3 seconds";
        });
        _detectFace();
      });
    } catch (e) {
      _showError("Error starting face scan: $e");
    }
  }

  // Detect face
  Future<void> _detectFace() async {
    if (!_isDetecting) {
      _isDetecting = true;
      try {
        final image = await _cameraController.takePicture();
        final inputImage = InputImage.fromFilePath(image.path);
        final faces = await _faceDetector.processImage(inputImage);

        if (faces.isNotEmpty) {
          setState(() {
            _instruction = "Look right for 3 seconds";
          });

          // Continue detecting face for the next phase
          Timer(const Duration(seconds: 3), () {
            setState(() {
              _instruction = "Look straight for 3 seconds";
            });
            _completeScan();
          });
        } else {
          _showError("No face detected. Please try again.");
        }
      } catch (e) {
        _showError("Error detecting face: $e");
      } finally {
        _isDetecting = false;
      }
    }
  }

  // Complete scan
  void _completeScan() {
    setState(() {
      _instruction = "Successful Face Scan!";
    });

    Timer(const Duration(seconds: 2), () {
      Navigator.pop(context); // Return to previous page
    });
  }

  @override
  void dispose() {
    _cameraController.dispose();
    _faceDetector.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_cameraController.value.isInitialized) {
      return const Center(child: CircularProgressIndicator());
    }

    return Scaffold(
      appBar: AppBar(title: const Text("Face Scan")),
      body: Stack(
        alignment: Alignment.center,
        children: [
          CameraPreview(_cameraController),
          ClipOval(
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.blueAccent, width: 2),
              ),
            ),
          ),
          Positioned(
            bottom: 50,
            child: Text(
              _instruction,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
