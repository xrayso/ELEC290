import 'package:flutter/material.dart';
import 'options_page.dart';

void main() {
  runApp(const ArcWayApp());
}

class ArcWayApp extends StatelessWidget {
  const ArcWayApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ArcWay',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Circular logo
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('assets/logo.png'),
                backgroundColor: Colors.transparent,
              ),
              const SizedBox(height: 20),

              // App title
              const Text(
                'ArcWay',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              const SizedBox(height: 40),

              // NetID input field
              TextField(
                decoration: const InputDecoration(
                  labelText: 'NetID',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.person),
                ),
              ),
              const SizedBox(height: 20),

              // Password input field
              TextField(
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                ),
              ),
              const SizedBox(height: 30),

              // Login button
                ElevatedButton(
                  onPressed: () {
                    // Navigate to OptionsPage
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const OptionsPage()),
                    );
                  },
                  child: const Text('Log In'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
